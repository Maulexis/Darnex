import React from "react";
import { motion } from "framer-motion";
import { Bot, Map, BarChart3, Compass, Lightbulb } from "lucide-react";

const Help = () => {
  const sections = [
    {
      icon: <Bot size={22} className="text-white" />,
      bg: "bg-indigo-500",
      border: "border-indigo-500",
      title: "AI Recommendations",
      content: (
        <ul className="list-disc ml-5 space-y-1">
          <li>
            <strong>Accepted</strong> – The action will be applied and removed
            from the list.
          </li>
          <li>
            <strong>Denied</strong> – The recommendation will be ignored and
            removed from the list.
          </li>
        </ul>
      ),
    },
    {
      icon: <Map size={22} className="text-white" />,
      bg: "bg-green-500",
      border: "border-green-500",
      title: "Map Section",
      content: (
        <p>
          The map shows the location of key railway stations. Future versions
          may display real-time train positions.
        </p>
      ),
    },
    {
      icon: <BarChart3 size={22} className="text-white" />,
      bg: "bg-yellow-500",
      border: "border-yellow-500",
      title: "Detailed View",
      content: (
        <p>
          Click <em>"Open Detailed View"</em> to access train schedules, routing
          details, and platform assignments.
        </p>
      ),
    },
    {
      icon: <Compass size={22} className="text-white" />,
      bg: "bg-blue-500",
      border: "border-blue-500",
      title: "Navigation",
      content: (
        <ul className="list-disc ml-5 space-y-1">
          <li>
            Use the header buttons for Home, Map, Performance, Scheduler,
            Junction Data, and Help.
          </li>
          <li>Hover effects improve usability.</li>
        </ul>
      ),
    },
    {
      icon: <Lightbulb size={22} className="text-white" />,
      bg: "bg-pink-500",
      border: "border-pink-500",
      title: "Tips",
      content: (
        <ul className="list-disc ml-5 space-y-1">
          <li>Review AI recommendations promptly to avoid congestion.</li>
          <li>Check the map frequently for operational updates.</li>
          <li>Use the Detailed View for advanced train management.</li>
        </ul>
      ),
    },
  ];

  return (
    <div className="grid gap-8 md:grid-cols-2">
      {sections.map((section, i) => (
        <motion.div
          key={i}
          className={`p-6 rounded-xl shadow-md hover:shadow-xl transition-all hover:scale-[1.02] bg-white border-2 ${section.border}`}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          {/* Header with Icon */}
          <div className="flex items-center gap-3 mb-3">
            <div
              className={`w-10 h-10 flex items-center justify-center rounded-full ${section.bg}`}
            >
              {section.icon}
            </div>
            <h2 className="text-lg font-semibold text-gray-800">
              {section.title}
            </h2>
          </div>

          {/* Content */}
          <div className="text-gray-600 leading-relaxed text-[15px]">
            {section.content}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default Help;
